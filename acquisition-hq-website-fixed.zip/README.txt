ACQUISITION HQ - HOW TO OPEN THE WORKING WEBSITE

ChatGPT file preview may display HTML without running JavaScript, so buttons can appear unresponsive in preview. This is a preview restriction, not a functioning website host.

FREE PUBLISHING VIA GITHUB PAGES
1. Create a free GitHub account if needed.
2. Create a new PUBLIC repository named acquisition-hq.
3. Upload index.html from this ZIP to the repository root.
4. In repository Settings > Pages, choose Deploy from a branch, main, / (root), Save.
5. Open the Pages URL shown in Settings after deployment.

IMPORTANT: The website code is public if hosted with GitHub Pages. Do not put private notes or credentials into source files. Saved records use browser localStorage and are device-specific; use Export Backup regularly. The website does not yet ingest live listings or sync weekly automation filters.
